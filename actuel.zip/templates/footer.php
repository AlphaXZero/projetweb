<?php require_once __DIR__ . "/../config/config.php" ?>
</main>
<footer>
    ©<em>van der Veen Georgé<em>
</footer>

</body>

</html>